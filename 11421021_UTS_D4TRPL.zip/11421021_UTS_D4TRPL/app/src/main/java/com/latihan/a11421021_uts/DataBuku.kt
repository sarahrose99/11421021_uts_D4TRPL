package com.latihan.a11421021_uts

object DataBuku {
    private val NamaBuku = arrayOf("Machine Learning",
    "Practical DL",
    "PyTorch")

    private val PenjelasanBuku = arrayOf("Through a series of recent breakthroughs, deep learning has\n" +
            "boosted the entire field of machine learning. Now, even programmers who know close to nothing about\n" +
            "this technology can use simple, efficient tools to implement programs capable of learning from\n" +
            "data. This practical book shows you how.", "Whether you’re a software engineer aspiring to enter the\n" +
            "world of deep learning, a veteran data scientist, or a hobbyist with a simple dream of making the next\n" +
            "viral AI app, you might have wondered where to begin. This step-by-step guide teaches you\n" +
            "how to build practical deep learning applications for the cloud, mobile, browsers, and edge\n" +
            "devices using a hands-on approach.", "Take the next steps toward mastering deep learning, the\n" +
            "machine learning method that’s transforming the world around us by the second. In this practical\n" +
            "book, you’ll get up to speed on key ideas using Facebook’s open source PyTorch framework and\n" +
            "gain the latest skills you need to create your very own neural networks.")

    private val jumlahBuku = arrayOf("50", "22", "10")

    private val GambarBuku = intArrayOf(R.drawable.booksatu,
    R.drawable.bookdua,
    R.drawable.booktiga)

    val listData: ArrayList<Buku>
        get() {
            val list = arrayListOf<Buku>()
            for (position in NamaBuku.indices){
                val buku = Buku()
                buku.judul = NamaBuku[position]        // posisi yang kesatu++
                buku.penjelasan = PenjelasanBuku[position]
                buku.jumlah = jumlahBuku[position]
                buku.gambar = GambarBuku[position]
                list.add(buku)
            }
            return list
        }
}