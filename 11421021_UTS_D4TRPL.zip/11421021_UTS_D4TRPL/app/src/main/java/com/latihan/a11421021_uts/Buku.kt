package com.latihan.a11421021_uts

class Buku (
    var judul: String = "",
    var penjelasan: String = "",
    var jumlah: String = "",
    var gambar: Int = 0
)