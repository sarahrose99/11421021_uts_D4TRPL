package com.latihan.a11421021_uts

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

class CardView(private val listBuku: ArrayList<Buku>): RecyclerView.Adapter<CardView.CardViewViewHolder>() {
    class CardViewViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var itemGambar: ImageView = itemView.findViewById(R.id.item_gambar)
        var itemJudul: TextView = itemView.findViewById(R.id.item_judul)
        var itemPenjelasan: TextView = itemView.findViewById(R.id.item_penjelasan)
        var itemJumlah: TextView = itemView.findViewById(R.id.jumlah)
        var btnTelp: Button = itemView.findViewById(R.id.telp_sensei)
        var btnBuy: Button = itemView.findViewById(R.id.btn_buy)
    }

    // mulai menjalankan view tersebut
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_row_buku, parent, false)
        return CardViewViewHolder(view)
    }

    // untuk memanggil
    override fun onBindViewHolder(holder: CardViewViewHolder, position: Int) {
        val daftar_buku = listBuku[position]

        Glide.with(holder.itemView.context)
            .load(daftar_buku.gambar)
            .apply(RequestOptions().override(350, 550))
            .into(holder.itemGambar)
        holder.itemJudul.text = daftar_buku.judul
        holder.itemPenjelasan.text = daftar_buku.penjelasan
        holder.itemJumlah.text = daftar_buku.jumlah
        holder.btnBuy.setOnClickListener{this}
        holder.btnTelp.setOnClickListener{this}
    }

    override fun getItemCount(): Int {
        return listBuku.size
    }

//     override fun onClick(v: View?){
//        R.id.telp_sensei -> {
//            val NumberTelephone = "081234567"
//            val Telephone = Intent(Intent.ACTION_DIAL, Uri.parse("tel: $NumberTelephone"))      // ini aksi aksi inten, kalau action dial untuk kamerea, action kamera juga ada, membuaka api juga ada
//            // ketika mengklik button telephne akan menjalankan aksi dial dalam intent yang bisa mengakses telephone. kalau udah dapat, di parsing no telephonenya
//            startActivity(Telephone)
//
//        }
    }
}