package com.latihan.a11421021_uts

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {

    private lateinit var ButtonBuy: Button        // memperkenalkan ketika mengklik button maka harus menemukan ke mana
    private lateinit var ButtonHarga: Button
    private lateinit var TextJumlah: TextView
    private lateinit var TextResult:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        ButtonBuy = findViewById(R.id.btn_belisatu)
        ButtonHarga = findViewById(R.id.btn_hargasatu)
        TextResult = findViewById(R.id.txtHarga)
        TextJumlah = findViewById(R.id.jumlahsatu)

        ButtonBuy.setOnClickListener(this)        //this ini akan mengakses berdasarkan class yang sama
        ButtonHarga.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.btn_belisatu->{
            }
        }
        }
}