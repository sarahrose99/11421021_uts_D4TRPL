package com.latihan.a11421021_uts

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rcv_Buku: RecyclerView
    private var list: ArrayList<Buku> = arrayListOf()
    private lateinit var ButtonParcelable: Button
    private lateinit var ButtonTelephone: Button
    private lateinit var ButtonBuy:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rcv_Buku = findViewById(R.id.rcv_buku)
        rcv_Buku.setHasFixedSize(true)       // di fix kan sizenya

//        ButtonBuy = findViewById<Button?>(R.id.rcv_buku).findViewById(R.id.btn_buy)

//        ButtonTelephone = findViewById<Button?>(R.id.rcv_buku).findViewById(R.id.telp_sensei)

        list.addAll(DataBuku.listData)       // menambahkan data di bangun ruang tadi
        showRecylerList();
    }

    private fun showRecylerList(){
        rcv_Buku.layoutManager = LinearLayoutManager(this)
        val cardViewHeroAdapter = CardView(list)
        rcv_Buku.adapter = cardViewHeroAdapter
    }
}